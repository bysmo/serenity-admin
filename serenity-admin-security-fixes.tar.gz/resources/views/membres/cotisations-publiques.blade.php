@extends('layouts.membre')

@section('title', 'Cagnottes publiques')

@section('content')
<div class="page-header">
    <h1 style="font-weight: 300; font-family: 'Ubuntu', sans-serif;"><i class="bi bi-globe"></i> Cagnottes publiques</h1>
</div>

<style>
.table-cotisations-membre { margin-bottom: 0; }
.table-cotisations-membre thead th {
    padding: 0.15rem 0.35rem !important;
    font-size: 0.65rem !important;
    line-height: 1.05 !important;
    vertical-align: middle !important;
    font-weight: 300 !important;
    font-family: 'Ubuntu', sans-serif !important;
    color: #ffffff !important;
    background-color: var(--primary-dark-blue) !important;
    border-bottom: 2px solid #dee2e6 !important;
}
.table-cotisations-membre tbody td {
    padding: 0.15rem 0.35rem !important;
    font-size: 0.65rem !important;
    line-height: 1.05 !important;
    vertical-align: middle !important;
    border-bottom: 1px solid #f0f0f0 !important;
    font-weight: 300 !important;
    font-family: 'Ubuntu', sans-serif !important;
    color: var(--primary-dark-blue) !important;
}
.table-cotisations-membre tbody tr:last-child td { border-bottom: none !important; }
table.table.table-cotisations-membre.table-hover tbody tr { background-color: #ffffff !important; transition: background-color 0.2s ease !important; }
table.table.table-cotisations-membre.table-hover tbody tr:nth-child(even) { background-color: #d4dde8 !important; }
table.table.table-cotisations-membre.table-hover tbody tr:hover { background-color: #b8c7d9 !important; cursor: pointer !important; }
table.table.table-cotisations-membre.table-hover tbody tr:nth-child(even):hover { background-color: #9fb3cc !important; }
.table-cotisations-membre td:last-child { white-space: nowrap; min-width: 120px; }
.table-cotisations-membre .actions-cell { display: flex; flex-wrap: wrap; gap: 0.2rem; align-items: center; }
.table-cotisations-membre .actions-cell .btn {
    padding: 0.15rem 0.3rem !important;
    font-size: 0.6rem !important;
    line-height: 1.1 !important;
    min-height: 20px !important;
    display: inline-flex !important;
    align-items: center !important;
    justify-content: center !important;
    gap: 0.1rem;
}
.table-cotisations-membre .actions-cell .btn i { font-size: 0.65rem !important; }
.table-cotisations-membre .btn-group-sm > .btn, .table-cotisations-membre .btn-group > .btn { border-radius: 0.2rem !important; }
.card-header-compact-cot { padding: 0.35rem 0.6rem !important; font-size: 0.75rem !important; font-weight: 300 !important; font-family: 'Ubuntu', sans-serif !important; }
</style>

<div class="card border-0 bg-transparent shadow-none">
    <div class="card-header border-0 bg-transparent px-0 pb-3" style="font-weight: 300; font-family: 'Ubuntu', sans-serif;">
        <i class="bi bi-list-ul"></i> Cagnottes publiques disponibles
    </div>
    <div class="card-body p-0">
        <div class="mb-4 d-flex align-items-center gap-2 w-100">
            <div class="input-group">
                <span class="input-group-text bg-white border-end-0"><i class="bi bi-search text-muted"></i></span>
                <input type="text" class="form-control border-start-0 ps-0 table-search-cot" placeholder="Rechercher par nom, tag, description..." id="searchCagnottes">
            </div>
        </div>

        @if($cotisations->total() > 0)
            <div class="row g-3" id="cotisations-grid">
                @foreach($cotisations as $cotisation)
                    @php 
                        $adhesion = $adhesions[$cotisation->id] ?? null; 
                        $currentMembreId = Auth::guard('membre')->id();
                        $canSeeAmount = ($cotisation->created_by_membre_id === $currentMembreId) || 
                                      ($cotisation->admin_membre_id === $currentMembreId);
                    @endphp
                    <div class="col-md-6 col-lg-4 cotisation-item">
                        <div class="card h-100 border shadow-sm" style="border-radius: 8px; transition: transform 0.2s;">
                            <div class="card-body d-flex flex-column">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <h6 class="card-title mb-0 text-truncate" style="font-weight: 500; color: var(--primary-dark-blue);" title="{{ $cotisation->nom }}">
                                        {{ $cotisation->nom }}
                                    </h6>
                                    @if($cotisation->actif)
                                        <span class="badge bg-success-subtle text-success border border-success-subtle rounded-pill" style="font-size: 0.65rem;">Active</span>
                                    @else
                                        <span class="badge bg-danger-subtle text-danger border border-danger-subtle rounded-pill" style="font-size: 0.65rem;">Inactive</span>
                                    @endif
                                </div>
                                
                                <p class="card-text small text-muted mb-3 flex-grow-1" style="font-size: 0.8rem;">
                                    {{ Str::limit($cotisation->description ?? 'Aucune description disponible', 100) }}
                                </p>
                                
                                <div class="bg-light rounded p-2 mb-3">
                                    <ul class="list-unstyled small mb-0 text-secondary" style="font-size: 0.75rem;">
                                        <li class="mb-1 d-flex justify-content-between">
                                            <span><i class="bi bi-tag me-1"></i> Type :</span>
                                            <strong>{{ ucfirst($cotisation->type) }}</strong>
                                        </li>
                                        <li class="mb-1 d-flex justify-content-between">
                                            <span><i class="bi bi-cash-stack me-1"></i> Montant :</span>
                                            @if($cotisation->type_montant === 'libre')
                                                <strong>Libre</strong>
                                            @else
                                                @if($canSeeAmount)
                                                    <strong>{{ number_format((float)($cotisation->montant ?? 0), 0, ',', ' ') }} XOF</strong>
                                                @else
                                                    <span class="text-muted fst-italic">Masqué</span>
                                                @endif
                                            @endif
                                        </li>
                                        <li class="mb-1 d-flex justify-content-between">
                                            <span><i class="bi bi-calendar-event me-1"></i> Début :</span>
                                            <span>{{ $cotisation->created_at->format('d/m/Y') }}</span>
                                        </li>
                                        <li class="mb-1 d-flex justify-content-between">
                                            <span><i class="bi bi-calendar-x me-1"></i> Fin :</span>
                                            <span>Illimitée</span>
                                        </li>
                                        <li class="d-flex justify-content-between">
                                            <span><i class="bi bi-receipt me-1"></i> Paiements :</span>
                                            <span class="badge bg-secondary rounded-pill">{{ $cotisation->paiements_count }}</span>
                                        </li>
                                    </ul>
                                </div>

                                <div class="d-grid gap-2 mt-auto">
                                    <a href="{{ route('membre.cotisations.show', $cotisation->id) }}" class="btn btn-outline-primary btn-sm">
                                        <i class="bi bi-eye"></i> Voir détails
                                    </a>
                                    
                                    @if(!$adhesion)
                                        <form action="{{ route('membre.cotisations.adherer', $cotisation) }}" method="POST" class="d-block w-100">
                                            @csrf
                                            <button type="submit" class="btn btn-success btn-sm w-100 shadow-sm">
                                                <i class="bi bi-person-plus-fill"></i> Adhérer
                                            </button>
                                        </form>
                                    @elseif($adhesion->statut === 'en_attente')
                                        <button class="btn btn-warning btn-sm w-100 disabled text-white" disabled>
                                            <i class="bi bi-hourglass-split"></i> En attente
                                        </button>
                                    @elseif($adhesion->statut === 'accepte' && $cotisation->actif)
                                        <div class="d-flex gap-1">
                                            @if($paydunyaEnabled)
                                                <button type="button" class="btn btn-primary btn-sm flex-grow-1 shadow-sm" onclick="initierPaiementPayDunya({{ $cotisation->id }}, '{{ addslashes($cotisation->nom) }}', {{ (float)($cotisation->montant ?? 0) }}, '{{ $cotisation->type_montant }}')">
                                                    <i class="bi bi-phone"></i> Payer par Mobile/Carte
                                                </button>
                                            @endif
                                            @if($pispiEnabled)
                                                <button type="button" class="btn btn-success btn-sm flex-grow-1 shadow-sm" onclick="initierPaiementPiSpi({{ $cotisation->id }}, '{{ addslashes($cotisation->nom) }}', {{ (float)($cotisation->montant ?? 0) }}, '{{ $cotisation->type_montant }}')">
                                                    <i class="bi bi-bank"></i> Payer par Compte/Banque
                                                </button>
                                            @endif
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
            
            @if($cotisations->hasPages())
                <div class="d-flex justify-content-end mt-4">
                    <div class="pagination-custom">{{ $cotisations->links() }}</div>
                </div>
            @endif
        @else
            <div class="text-center py-5 bg-white rounded shadow-sm">
                <i class="bi bi-inbox text-muted" style="font-size: 3rem; opacity: 0.5;"></i>
                <h5 class="mt-3 text-muted fw-light">Aucune cagnotte publique disponible</h5>
                <p class="text-muted small">Revenez plus tard pour voir les nouvelles cagnottes.</p>
            </div>
        @endif
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchCagnottes');
    if (!searchInput) return;

    searchInput.addEventListener('input', function() {
        const query = this.value.trim().toLowerCase();
        const items = document.querySelectorAll('.cotisation-item');
        
        items.forEach(function(item) {
            const text = item.textContent.replace(/\s+/g, ' ').toLowerCase();
            if (text.indexOf(query) !== -1) {
                item.style.display = '';
            } else {
                item.style.display = 'none';
            }
        });
    });
});
</script>

@if($paydunyaEnabled || $pispiEnabled)
<!-- Modal confirmation paiement -->
<div class="modal fade" id="modalPaiementPayDunya" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title" id="modalPayDunyaTitle">Confirmation de paiement</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p id="modalPayDunyaMessage" class="mb-2">Voulez-vous payer la cagnotte <strong id="modalPayDunyaNom"></strong> d'un montant de <strong id="modalPayDunyaMontant"></strong> XOF ?</p>
                <div id="montantInputGroup" class="mt-3 mb-3" style="display: none;">
                    <label for="montant_saisi" class="form-label small">Montant à payer (XOF) :</label>
                    <input type="number" id="montant_saisi" class="form-control" placeholder="Entrez le montant" min="100">
                </div>
                <p class="small text-muted mb-0" id="modalPayDunyaNote"></p>
            </div>
            <div class="modal-footer border-0 pt-0">
                <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Annuler</button>
                <button type="button" id="modalPayDunyaConfirmLink" class="btn btn-primary btn-sm">Confirmer le paiement</button>
            </div>
        </div>
    </div>
</div>

<script>
let currentCagnotteId = null;
let currentMethod = 'paydunya';

function initierPaiementPayDunya(cotisationId, nomCagnotte, montant, typeMontant) {
    currentCagnotteId = cotisationId;
    currentMethod = 'paydunya';
    
    const inputGroup = document.getElementById('montantInputGroup');
    const msgEl = document.getElementById('modalPayDunyaMessage');
    
    if (typeMontant === 'libre') {
        inputGroup.style.display = 'block';
        msgEl.innerHTML = 'Voulez-vous payer pour la cagnotte "<strong>' + escapeHtml(nomCagnotte) + '</strong>" ? Veuillez préciser le montant ci-dessous.';
    } else {
        inputGroup.style.display = 'none';
        msgEl.innerHTML = 'Voulez-vous payer la cagnotte "<strong>' + escapeHtml(nomCagnotte) + '</strong>" d\'un montant de <strong>' + new Intl.NumberFormat('fr-FR').format(montant) + ' XOF</strong> ?';
    }
    
    document.getElementById('modalPayDunyaTitle').innerHTML = '<i class="bi bi-phone"></i> Paiement par Mobile/Carte';
    document.getElementById('modalPayDunyaNote').textContent = "Vous allez être redirigé vers la page de paiement sécurisée.";
    
    var modal = new bootstrap.Modal(document.getElementById('modalPaiementPayDunya'));
    modal.show();
}

function initierPaiementPiSpi(cotisationId, nomCagnotte, montant, typeMontant) {
    currentCagnotteId = cotisationId;
    currentMethod = 'pispi';
    
    const inputGroup = document.getElementById('montantInputGroup');
    const msgEl = document.getElementById('modalPayDunyaMessage');
    
    if (typeMontant === 'libre') {
        inputGroup.style.display = 'block';
        msgEl.innerHTML = 'Voulez-vous payer pour la cagnotte "<strong>' + escapeHtml(nomCagnotte) + '</strong>" ? Veuillez préciser le montant ci-dessous.';
    } else {
        inputGroup.style.display = 'none';
        msgEl.innerHTML = 'Voulez-vous payer la cagnotte "<strong>' + escapeHtml(nomCagnotte) + '</strong>" d\'un montant de <strong>' + new Intl.NumberFormat('fr-FR').format(montant) + ' XOF</strong> ?';
    }
    
    document.getElementById('modalPayDunyaTitle').innerHTML = '<i class="bi bi-bank"></i> Paiement par Compte/Banque';
    document.getElementById('modalPayDunyaNote').textContent = "Une demande de paiement sera envoyée directement sur votre téléphone.";
    
    var modal = new bootstrap.Modal(document.getElementById('modalPaiementPayDunya'));
    modal.show();
}

document.getElementById('modalPayDunyaConfirmLink')?.addEventListener('click', function(e) {
    if (currentCagnotteId) {
        const montantSaisi = document.getElementById('montant_saisi').value;
        const isLibre = document.getElementById('montantInputGroup').style.display === 'block';

        if (isLibre && (!montantSaisi || montantSaisi < 100)) {
            alert("Veuillez saisir un montant valide (min 100 XOF).");
            return;
        }

        let route = currentMethod === 'paydunya' 
            ? '{{ route("membre.cotisations.paydunya", ":id") }}' 
            : '{{ route("membre.cotisations.pispi", ":id") }}';
            
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = route.replace(':id', currentCagnotteId);
        
        const csrf = document.createElement('input');
        csrf.type = 'hidden';
        csrf.name = '_token';
        csrf.value = '{{ csrf_token() }}';
        form.appendChild(csrf);

        if (isLibre) {
            const montantInput = document.createElement('input');
            montantInput.type = 'hidden';
            montantInput.name = 'montant';
            montantInput.value = montantSaisi;
            form.appendChild(montantInput);
        }
        
        document.body.appendChild(form);
        form.submit();
    }
});
</script>
@endif
@endsection
